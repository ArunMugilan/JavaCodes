/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixerrors;

/*******************************************************************************
 * Author : Arun Mugilan
 * Program : WhoAmi
 * Description : To demonstrate the simple Java Program
 * Date : 18 October 2021
 * Modified Date : None
 * Version : 1.0
 ******************************************************************************/

public class FixErrors {

    public static void main(String[] args) {
        System.out.print("Welcome!");
    }
    
}
