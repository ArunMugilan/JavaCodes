/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package activity2;

/*******************************************************************************
 * Author : Arun Mugilan
 * Program : WhoAmi
 * Description : To demonstrate the simple Java Program
 * Date : 18 October 2021
 * Modified Date : None
 * Version : 1.0
 ******************************************************************************/
public class WhoAmI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Arun Mugilan A/L Sargunan. Matrics Number: S63746. Program of Computer Science (Mobile Computing)");
    }
    
}
