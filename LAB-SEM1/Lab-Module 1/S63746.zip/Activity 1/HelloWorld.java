/******************************************************************
* Author : Arun Mugilan
* Program Name : HelloWorld
* Description : To demonstrate a simple Java program
* Date : 18 October 2021
* Modifies Date : None
* Version : 1.0
*******************************************************************/

public class HelloWorld
{
	public static void main (String [] args)
	{
		System.out.println("Hello World! This is my first time using Java.");
	}
}


