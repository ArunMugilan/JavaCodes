/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myprofile;

/*******************************************************************************
 * Author : Arun Mugilan
 * Program : WhoAmi
 * Description : To demonstrate the simple Java Program
 * Date : 18 October 2021
 * Modified Date : None
 * Version : 1.0
 ******************************************************************************/
public class MyProfile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println( "Resume\n ");   
         System.out.println ("Name : Arun Mugilan A/L Sargunan. ");
         System.out.println ("Address : No 19, Jalan Perdana 2/4, Taman Serai Perdana, 34300 Bagan Serai, Perak.");
         System.out.println ("Matrics Number: S63746.");
         System.out.println ("Program : Program of Computer Science (Mobile Computing)");
  
                
             
    }
    
}
