/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package activity3;

import java.util.Scanner;

/*******************************************************************************
 * Author : Arun Mugilan
 * Program : SUDOKU
 * Description : To demonstrate the simple Java Program
 * Date : 24 November 2021
 * Modified Date : None
 * Version : 1.0
 ******************************************************************************/
import java.util.Scanner;
public class Activity3 {

    
    public static void main(String[] args) {
        int num1,num2,odd,even,x;
        System.out.println("Instruction.\nFirst integer must be less than second integer.\n ");
        Scanner a =new Scanner(System.in);
        System.out.print("Please enter your first integer : ");
        num1= a.nextInt();
        System.out.print("Please enter your second integer : ");
        num2= a.nextInt();
        while(num1>num2){
            System.out.println("Incorrect! please enter your integer again");  
            System.out.print("Please enter your first integer : ");
            num1= a.nextInt();
            System.out.print("Please enter your second integer : ");
            num2= a.nextInt();
        }
        x= num1;
        while(x<num2){
            if (x %2 !=0)  
                System.out.println("Odd number is : " +x); 
            x ++ ;
        }
        x= num1;
        while(x<num2){
             if (x %2 ==0)  
                System.out.println("Even number is : " +x); 
            x ++ ;
       }
    }
    
}
