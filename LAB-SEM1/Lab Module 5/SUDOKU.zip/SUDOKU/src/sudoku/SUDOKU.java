/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sudoku;

/*******************************************************************************
 * Author : Arun Mugilan
 * Program : SUDOKU
 * Description : To demonstrate the simple Java Program
 * Date : 24 November 2021
 * Modified Date : None
 * Version : 1.0
 ******************************************************************************/
import java.util.Scanner;
public class SUDOKU {

    
    public static void main(String[] args) {
        Scanner a = new Scanner(System.in);
        System.out.println("Welcome to Sudoku Game");
        System.out.println("Let's Go! Look at the game carefully");
        System.out.println("This is the question.\n");
        System.out.println("    A B C | D E F | G H I");
        System.out.println("(1) 5 0 0 | 4 6 7 | 3 0 9");
        System.out.println("(2) 9 0 3 | 8 1 0 | 4 2 7");
        System.out.println("(3) 1 7 4 | 2 0 3 | 0 0 0");
        System.out.println("--------------------------");
        System.out.println("(4) 2 3 1 | 9 7 6 | 8 5 4");
        System.out.println("(5) 8 5 7 | 1 2 4 | 0 9 0");
        System.out.println("(6) 4 9 6 | 3 0 8 | 1 7 2");
        System.out.println("-------------------------");
        System.out.println("(7) 0 0 0 | 0 8 9 | 2 6 0");
        System.out.println("(8) 7 8 2 | 6 4 1 | 0 0 5");
        System.out.println("(9) 0 1 0 | 0 0 0 | 7 0 8\n");
        System.out.println("You need to enter a number for each 0 in the sudoku one by one from line 1.\n "
                       + "(Numbers for rows, Alphabets for colums)");
        
        System.out.print("Enter an answer for placement B1: ");
        int B1 = a.nextInt();
        System.out.print("Enter an answer for placement B1: ");
        int C1 = a.nextInt();
        System.out.print("Enter an answer for placement B2: ");
        int B2 = a.nextInt();
        System.out.print("Enter an answer for placement F2: ");
        int F2 = a.nextInt();
        System.out.print("Enter an answer for placement E3: ");
        int E3 = a.nextInt();
        System.out.print("Enter an answer for placement H1: ");
        int H1 = a.nextInt();
        System.out.print("Enter an answer for placement G3: ");
        int G3 = a.nextInt();
        System.out.print("Enter an answer for placement H3: ");
        int H3 = a.nextInt();
        System.out.print("Enter an answer for placement I3: ");
        int I3 = a.nextInt();
        System.out.print("Enter an answer for placement E6: ");
        int E6 = a.nextInt();
        System.out.print("Enter an answer for placement G5: ");
        int G5 = a.nextInt();
        System.out.print("Enter an answer for placement I5: ");
        int I5 = a.nextInt();
        System.out.print("Enter an answer for placement A7: ");
        int A7 = a.nextInt();
        System.out.print("Enter an answer for placement B7: ");
        int B7 = a.nextInt();
        System.out.print("Enter an answer for placement C7: ");
        int C7 = a.nextInt();
        System.out.print("Enter an answer for placement A9: ");
        int A9 = a.nextInt();
        System.out.print("Enter an answer for placement C9: ");
        int C9 = a.nextInt();
        System.out.print("Enter an answer for placement D7: ");
        int D7 = a.nextInt();
        System.out.print("Enter an answer for placement D9: ");
        int D9 = a.nextInt();
        System.out.print("Enter an answer for placement E9: ");
        int E9 = a.nextInt();
        System.out.print("Enter an answer for placement F9: ");
        int F9 = a.nextInt();
        System.out.print("Enter an answer for placement I7: ");
        int I7 = a.nextInt();
        System.out.print("Enter an answer for placement G8: ");
        int G8 = a.nextInt();
        System.out.print("Enter an answer for placement H8: ");
        int H8 = a.nextInt();
        System.out.print("Enter an answer for placement H9: ");
        int H9 = a.nextInt();
        
        System.out.println("5 "+ B1 + " "+ C1+" | 4 6 7 | 3 "+H1+" 9");
        System.out.println("9 "+ B2 +" 3 | 8 1 "+ F2 +" | 4 2 7");
        System.out.println("1 7 4 | 2 "+ E3 +" 3 | "+ G3 +" "+H3+" "+I3+"");
        System.out.println("---------------------");
        System.out.println("2 3 1 | 9 7 6 | 8 5 4");
        System.out.println("8 5 7 | 1 2 4 | "+ G5 +" 9 "+I5+"");
        System.out.println("4 9 6 | 3 "+ E6 +" 8 | 1 7 2");
        System.out.println("---------------------");
        System.out.println(""+A7+" "+B7+" "+C7+" | "+D7+" 8 9 | 2 6 "+I7+"");
        System.out.println("7 8 2 | 6 4 1 | "+G8+" "+H8+" 5");
        System.out.println(""+A9+" 1 "+C9+" | "+D9+" "+E9+" "+F9+" | 7 "+H9+" 8");
        System.out.println("This is yout answer.");
        
        
        
                
    }
    
}
